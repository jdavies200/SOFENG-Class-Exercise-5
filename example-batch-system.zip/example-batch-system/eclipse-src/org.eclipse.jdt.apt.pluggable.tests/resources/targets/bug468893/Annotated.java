package targets.bug468893;

@Annotation
public class Annotated {
}