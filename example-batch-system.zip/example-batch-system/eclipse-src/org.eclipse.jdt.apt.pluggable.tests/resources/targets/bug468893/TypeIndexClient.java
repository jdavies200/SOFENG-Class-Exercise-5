package targets.bug468893;

import generated.TypeIndex;

public class TypeIndexClient implements TypeIndex {
}