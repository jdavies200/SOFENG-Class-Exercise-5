package targets.bug468893;
import java.lang.annotation.Inherited;

@Inherited
public @interface Annotation {
}