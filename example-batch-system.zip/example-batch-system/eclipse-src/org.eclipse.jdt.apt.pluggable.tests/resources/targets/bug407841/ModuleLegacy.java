package targets.bug407841;

import org.eclipse.jdt.apt.pluggable.tests.annotations.Module;

@Module(key=ModuleCore.KEY)
public class ModuleLegacy {
	public static final String KEY = "LEGACY";
}
