package targets.bug387956;

/**
 * Using {@link Generate} on {@link Entity} will generate the empty
 * {@link generated.GeneratedEntity} class.
 */
@Generate
public class Entity {

}