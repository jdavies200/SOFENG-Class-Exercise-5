package targets.bug419769;

@Deprecated
public class AnnotatedClass {
}
