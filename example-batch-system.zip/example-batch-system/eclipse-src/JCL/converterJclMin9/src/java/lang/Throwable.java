package java.lang;

public class Throwable {
}
