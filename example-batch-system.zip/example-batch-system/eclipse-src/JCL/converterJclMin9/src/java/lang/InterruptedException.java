package java.lang;

public class InterruptedException extends Exception {
}
