package java.lang;

public interface CharSequence {
	int length();
}
