package java.util;

public interface Map<K,V> {

}